#Devon Poole
#3/13/2024
#P2HW2
#Understanding of Lists

mod1 = float(input("Enter grade for Module 1: "))
mod2 = float(input("Enter grade for Module 2: "))
mod3 = float(input("Enter grade for Module 3: "))
mod4 = float(input("Enter grade for Module 4: "))
mod5 = float(input("Enter grade for Module 5: "))
mod6 = float(input("Enter grade for Module 6: "))

grades = [mod1, mod2, mod3, mod4, mod5, mod6]

total_sum = sum(grades)
average = total_sum / len(grades)

# ---------Results---------

print(f"Lowest Grade: {min(grades)}")
print(f"Highest Grade: {max(grades)}")
print(f"Sum of Grades: {total_sum}")
print(f"Average: {average}")


if average >= 90:
    print('Your grade is: A')
elif average >= 80:
    print('Your grade is: B')
elif average >= 70:
    print('Your grade is: C')
elif average >= 60:
    print('Your grade is: D')
else:
    print('Your grade is: F')
