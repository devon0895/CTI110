#DevonPoole
#3/21/24
#P3HW2
#Calculating employee pay for hours worked

totalhrs = (float(input("Enter number of hours worked: ")))
payrate = (float(input("Enter employee's pay rate: ")))
max_hrs = 40
reg_hrs = totalhrs < 40
name = input("Enter employee's name: ")

print("------------" * 7)

print("Employee name: " , name)

print("Hours Worked     Pay Rate        OverTime Hours      OverTime Pay        RegHour Pay         Gross Pay")

print(f"{totalhrs} {payrate} {totalhrs - max_hrs} {(payrate * 1.5) * (totalhrs - max_hrs)} {payrate * max_hrs} {(payrate * max_hrs) + ((payrate * 1.5) * (totalhrs - max_hrs))}")